package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    double num1,num2,res;
    Button botao;
    EditText numero1, numero2;
    TextView resultado;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);
        numero1 = findViewById(R.id.numer1);
        numero2 = findViewById((R.id.numer2));
        resultado = findViewById(R.id.txt_result);
        botao = findViewById(R.id.btn_calc);

        String [] operaçoes = {"Selecionar Operação", "Somar", "Subtrair", "Multiplicar", "Dividir"};

        ArrayAdapter adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, operaçoes);

        spinner.setAdapter(adaptador);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String operacao = spinner.getSelectedItem().toString();
                if (operacao.equals("Selecionar Operação")) {
                    Toast.makeText(getApplicationContext(), "Operação Não Selecionada", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (numero1.getText().toString().isEmpty() || numero2.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Campo Vazio", Toast.LENGTH_SHORT).show();
                    return;
                }

                num1 = Double.parseDouble(numero1.getText().toString());
                num2 = Double.parseDouble(numero2.getText().toString());
                res = 0;

                try {
                    if (operacao.equals("Somar")){
                        res = (num1 + num2);
                    } else if (operacao.equals("Subtrair")){
                        res = (num1 - num2);
                    } else if (operacao.equals("Multiplicar")){
                        res = (num1 * num2);
                    } else if (operacao.equals("Dividir")){
                        if (num2 == 0 ) {
                            throw new ArithmeticException("Não é possível dividir por 0");
                        }
                        res = num1 / num2;
                    }

                } catch (ArithmeticException e) {
                    Toast.makeText(getApplicationContext(), "Erro: "+ e.getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }
                resultado.setText(""+res);
            }
        });


    }
}